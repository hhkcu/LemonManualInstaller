async function makeQuery(query, variables = {}) {
   const req = await fetch("https://ritzmultiplex.com/graphql", {
      method: "POST",
      headers: {
         "content-type": "application/json",
         "is-electron-mode": "false",
         "site-id": "29",
         "circuit-id": "15",
         "client-type": "consumer",
         "user-agent":
            "Mozilla/5.0 (X11; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0"
      },
      body: JSON.stringify({ query, variables: JSON.stringify(variables) })
   });
   const data = await req.json();
   return data.data;
}

const date = process.argv[2];

const showings = await makeQuery(
   `
    query ($date: String) {
        showingsForDate(date: $date) {
            data {
                id
                time
		screen {
		    name
		}
                movie {
                    name
                    duration
                }
            }
        }
    }
`,
   {
      date
   }
);

const data = showings.showingsForDate.data;

const time = (ts) => {
   const d = new Date(ts);
   return d.toTimeString().substring(0, 5);
};

const addMinutes = (d, mins) => {
   d.setMinutes(d.getMinutes() + mins);
};

const onlyId = "272226";
let showEmpty = false;
for (let i = 3; i < process.argv.length; i++) {
   const arg = process.argv[i];
   switch (arg) {
      case "--show-empty":
         showEmpty = true;
         break;
      default:
         break;
   }
}
const printedShowings = [];

for (const showing of data) {
   //if (showing.id != onlyId) return;
   // Apparently the seatChart of Showing isn't updated for claimed seats
   // This specific request shows the claimed seats but not Showing.seatChart
   // Most dogshit design ever, just use one request PLEASE. This is the specific point
   // of GraphQL.
   const seatChartData = await makeQuery(
      `
       query ($showingId: ID!, $orderId: ID) {
  seatChartForShowing(showingId: $showingId, orderId: $orderId) {
    id
    name
    displayOrder
    seatCount
    seatChartOptions
    seatChart
    __typename
  }
}
    `,
      {
         orderId: null,
         showingId: showing.id
      }
   );
   const seatChart = JSON.parse(seatChartData.seatChartForShowing.seatChart);
   let taken = 0;
   const takenSeats = [];
   let endTime = new Date(showing.time);
   addMinutes(endTime, showing.movie.duration + 20); // +20 accounts for the ads runtime
   /**
    * Seat types:
    * - couch-left and couch-right are halves of one VIP double seat
    * - recliner-seat is a single VIP seat
    * - regular-seat is a single regular seat
    * - couch-corner-left is a VIP lounge seat
    * - wheelchair is a wheelchair spot icon
    */
   for (const row of seatChart) {
      for (const seat of row) {
         if (seat.reserved === true) {
            if (seat.seatType.includes("couch")) taken += 0.5;
            else taken += 1;
            if (seat.seatType == "couch-right") continue;
            takenSeats.push(`${seat.name} (${seat.seatType})`);
         }
      }
   }
   if (taken === 0 && showEmpty === false) continue;
   printedShowings.push({
      name: showing.movie.name,
      startTime: showing.time,
      endTime,
      screen: showing.screen.name,
      takenSeats,
      id: showing.id
   });
}

printedShowings.sort((a, b) => a.startTime - b.startTime);

printedShowings.forEach((showing) => {
   console.log(
      `\n${showing.name} at ${time(showing.startTime)}, ending at ${time(showing.endTime)} (${showing.id})`
   );
   console.log(`In ${showing.screen}`);
   console.log(`${showing.takenSeats.length} seats taken`);
   console.log(`${showing.takenSeats.join(", ")}`);
});
