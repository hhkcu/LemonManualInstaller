#!/bin/bash
npm install
node server.mjs &
sleep 5
termux-open-url http://localhost:3000
