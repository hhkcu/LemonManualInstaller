import express from "express";
import fetch from "node-fetch";
import path from "node:path";

const app = express();
const port = 3000;

app.use(express.json());

async function makeQuery(query, variables = {}) {
   const req = await fetch("https://ritzmultiplex.com/graphql", {
      method: "POST",
      headers: {
         "content-type": "application/json",
         "is-electron-mode": "false",
         "site-id": "29",
         "circuit-id": "15",
         "client-type": "consumer",
         "user-agent":
            "Mozilla/5.0 (X11; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0"
      },
      body: JSON.stringify({ query, variables: JSON.stringify(variables) })
   });
   const data = await req.json();
   return data;
}

app.get("/", async (req, res) => {
   res.sendFile(path.resolve("client.html"));
});

app.get("/s/:asset", (req, res) => {
	res.sendFile(path.resolve(req.params.asset));
})

app.post("/graphql", async (req, res) => {
   const { query, variables } = req.body;
   try {
      const data = await makeQuery(query, variables);
      res.json(data);
   } catch (error) {
      console.error("GraphQL query error:", error);
      res.status(500).json({ error: "Internal Server Error" });
   }
});

app.listen(port, () => {
   console.log(`Server listening at http://localhost:${port}`);
});
