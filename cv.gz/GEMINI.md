See chart.mjs for implementation and API communication of the command line tool.
seats.svg contains SVG <symbol>s for all seat types

You need to have some sort of style that separates unclaimed seats from claimed seats.
Aim to have a list of seat chart templates that are simple to write ASCII art that defines the structure of a specific screen.

All seat types are in a comment in chart.mjs

Try not to install any web frameworks that would bloat the setup, try to keep things self contained
